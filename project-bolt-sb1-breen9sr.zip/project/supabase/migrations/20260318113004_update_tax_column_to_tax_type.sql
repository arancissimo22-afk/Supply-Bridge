/*
  # Update Tax Column to Tax Type

  1. Changes
    - Drop the `tax_rate` column from products table
    - Add `tax_type` column as text with default 'tax_free'
  
  2. Notes
    - Tax type can be either 'tax_free' or 'tax_inclusive'
    - Default is 'tax_free' for all products
*/

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'products' AND column_name = 'tax_rate'
  ) THEN
    ALTER TABLE products DROP COLUMN tax_rate;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'products' AND column_name = 'tax_type'
  ) THEN
    ALTER TABLE products ADD COLUMN tax_type TEXT DEFAULT 'tax_free';
  END IF;
END $$;
