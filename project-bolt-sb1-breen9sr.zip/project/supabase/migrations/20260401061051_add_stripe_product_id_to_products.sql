/*
  # Add Stripe Product ID to Products Table

  1. Changes
    - Add `stripe_product_id` column to products table to track Stripe products
    - Add unique constraint on `stripe_product_id` to prevent duplicates
    - Create index on `stripe_product_id` for faster lookups

  2. Notes
    - This allows syncing products from Stripe and preventing duplicates
    - Existing products will have NULL stripe_product_id (manually added products)
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'products' AND column_name = 'stripe_product_id'
  ) THEN
    ALTER TABLE products ADD COLUMN stripe_product_id text;
  END IF;
END $$;

-- Create unique index on stripe_product_id (allowing NULL for manually added products)
CREATE UNIQUE INDEX IF NOT EXISTS idx_products_stripe_product_id 
ON products(stripe_product_id) 
WHERE stripe_product_id IS NOT NULL;