/*
  # Add MOQ (Minimum Order Quantity) to Products

  1. Changes
    - Add `moq` column to `products` table
      - Type: integer
      - Default: 1 (minimum order quantity of 1)
      - Not null constraint to ensure all products have a MOQ value
  
  2. Notes
    - MOQ (Minimum Order Quantity) represents the minimum number of units a customer must purchase
    - Default value of 1 means no minimum restriction by default
*/

-- Add MOQ column to products table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'products' AND column_name = 'moq'
  ) THEN
    ALTER TABLE products ADD COLUMN moq integer DEFAULT 1 NOT NULL;
  END IF;
END $$;