/*
  # Create payment credentials table

  1. New Tables
    - `payment_credentials`
      - `id` (uuid, primary key)
      - `bsb` (text) - BSB number for bank account
      - `account_number` (text) - Bank account number
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
  
  2. Security
    - Enable RLS on `payment_credentials` table
    - Add policy for public read access (anyone can view payment details for checkout)
    - Add policy for public insert/update access (admin functionality without auth)
*/

CREATE TABLE IF NOT EXISTS payment_credentials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bsb text NOT NULL,
  account_number text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE payment_credentials ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read access to payment credentials"
  ON payment_credentials
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Allow public insert access to payment credentials"
  ON payment_credentials
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow public update access to payment credentials"
  ON payment_credentials
  FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);