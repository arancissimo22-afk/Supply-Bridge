/*
  # Update Products Table Policies for Public Access
  
  1. Changes
    - Remove authenticated-only policies for insert, update, and delete
    - Add public access policies for insert, update, and delete operations
    - Maintain public read access
  
  2. Security
    - Public read access for all users (anyone can view products)
    - Public insert access (allows unauthenticated users to create products)
    - Public update access (allows unauthenticated users to modify products)
    - Public delete access (allows unauthenticated users to remove products)
  
  3. Notes
    - This is appropriate for a public product management system
    - Consider adding authentication later for production use
*/

DROP POLICY IF EXISTS "Authenticated users can insert products" ON products;
DROP POLICY IF EXISTS "Authenticated users can update products" ON products;
DROP POLICY IF EXISTS "Authenticated users can delete products" ON products;

CREATE POLICY "Anyone can insert products"
  ON products
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can update products"
  ON products
  FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can delete products"
  ON products
  FOR DELETE
  TO public
  USING (true);
