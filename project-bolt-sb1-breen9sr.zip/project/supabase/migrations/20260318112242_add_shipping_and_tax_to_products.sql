/*
  # Add Shipping Cost and Tax Rate to Products

  1. Changes
    - Add `shipping_cost` column to products table (decimal, default 0)
    - Add `tax_rate` column to products table (decimal, default 0 for tax-free items)
  
  2. Notes
    - Shipping cost in dollars (e.g., 10.00 for $10 shipping)
    - Tax rate as percentage (e.g., 10 for 10% tax, 0 for tax-free)
    - Both fields default to 0 to support free shipping and tax-free products
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'products' AND column_name = 'shipping_cost'
  ) THEN
    ALTER TABLE products ADD COLUMN shipping_cost DECIMAL(10,2) DEFAULT 0;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'products' AND column_name = 'tax_rate'
  ) THEN
    ALTER TABLE products ADD COLUMN tax_rate DECIMAL(5,2) DEFAULT 0;
  END IF;
END $$;
