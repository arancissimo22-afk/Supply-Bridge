/*
  # Update Storage Policies for Product Images
  
  1. Changes
    - Remove authenticated-only policies
    - Add public upload/update/delete policies for product images
    - Maintain public read access
  
  2. Security
    - Public read access for all users (images are publicly viewable)
    - Public upload access (allows unauthenticated users to upload)
    - Public update/delete access (for managing product images)
  
  3. Notes
    - This is appropriate for a public product management system
    - Consider adding authentication later for production use
*/

DROP POLICY IF EXISTS "Authenticated users can upload product images" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can update product images" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can delete product images" ON storage.objects;

CREATE POLICY "Anyone can upload product images"
  ON storage.objects
  FOR INSERT
  TO public
  WITH CHECK (bucket_id = 'product-images');

CREATE POLICY "Anyone can update product images"
  ON storage.objects
  FOR UPDATE
  TO public
  USING (bucket_id = 'product-images')
  WITH CHECK (bucket_id = 'product-images');

CREATE POLICY "Anyone can delete product images"
  ON storage.objects
  FOR DELETE
  TO public
  USING (bucket_id = 'product-images');
