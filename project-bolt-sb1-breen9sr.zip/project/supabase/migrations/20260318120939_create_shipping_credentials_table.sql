/*
  # Create shipping credentials table

  1. New Tables
    - `shipping_credentials`
      - `id` (uuid, primary key)
      - `name` (text) - Full name for shipping
      - `email` (text) - Contact email
      - `address` (text) - Street address
      - `city` (text) - City
      - `postal_code` (text) - Postal/ZIP code
      - `country` (text) - Country
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `shipping_credentials` table
    - Add policy for public read access (needed for checkout)
    - Add policy for public write access (for admin operations)

  3. Notes
    - This table stores default shipping information
    - Only one record should exist at a time for default credentials
*/

CREATE TABLE IF NOT EXISTS shipping_credentials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  address text NOT NULL,
  city text NOT NULL,
  postal_code text NOT NULL,
  country text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE shipping_credentials ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read access to shipping credentials"
  ON shipping_credentials
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Allow public insert access to shipping credentials"
  ON shipping_credentials
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Allow public update access to shipping credentials"
  ON shipping_credentials
  FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow public delete access to shipping credentials"
  ON shipping_credentials
  FOR DELETE
  TO public
  USING (true);