export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  images: string[];
  category: string;
  moq: number;
  packSize: number;
  inStock: boolean;
  shipping_cost?: number;
  tax_type?: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Order {
  id: string;
  stripe_session_id: string;
  customer_email: string;
  customer_name?: string;
  items: CartItem[];
  subtotal: number;
  total: number;
  status: string;
  created_at: string;
}
