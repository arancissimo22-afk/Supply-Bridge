# Supplybridge - E-Commerce Platform

A modern, open wholesale e-commerce website built with Next.js, TypeScript, and Stripe. No login required - customers can browse products and checkout directly.

## Features

- Browse products with real-time Stripe integration
- Category filtering and search functionality
- Wholesale-specific features (MOQ, Pack Size)
- Smart quantity validation in cart
- Secure checkout via Stripe Checkout
- Order storage in Supabase
- Fully responsive design

## Tech Stack

- **Frontend**: Next.js 13 (App Router), TypeScript, Tailwind CSS
- **Payment**: Stripe Checkout
- **Database**: Supabase
- **UI Components**: shadcn/ui with Radix UI

## Project Structure

### Key Files

#### Cart Logic & Validation
- `contexts/CartContext.tsx` - Global cart state management with localStorage persistence
- `app/cart/page.tsx` - Cart page with validation logic (MOQ, pack size, minimum order)

#### Stripe Integration
- `app/api/stripe/products/route.ts` - Fetches products from Stripe with metadata mapping
- `app/api/stripe/checkout/route.ts` - Creates Stripe Checkout sessions

#### Order Management
- `app/api/orders/route.ts` - Saves completed orders to Supabase
- `app/checkout/success/page.tsx` - Order confirmation page

#### Components
- `components/Header.tsx` - Navigation with cart count
- `components/Footer.tsx` - Site footer with links
- `components/ProductCard.tsx` - Reusable product display
- `components/QuantitySelector.tsx` - Quantity picker with validation

#### Pages
- `app/page.tsx` - Home page with hero, categories, and featured products
- `app/shop/page.tsx` - Product listing with search, filter, and sort
- `app/product/[id]/page.tsx` - Product detail with wholesale features

## Setup Instructions

### 1. Environment Variables

Update `.env` with your credentials:

```env
# Supabase (already configured)
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url

# Stripe (required)
STRIPE_SECRET_KEY=your_stripe_secret_key_here
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=your_stripe_publishable_key_here

# App URL
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

### 2. Get Stripe API Keys

1. Go to [Stripe Dashboard](https://dashboard.stripe.com)
2. Navigate to **Developers > API keys**
3. Copy your **Publishable key** and **Secret key**
4. Paste them into your `.env` file

### 3. Add Products in Stripe

To add products that work with the wholesale features:

1. Go to [Stripe Dashboard > Products](https://dashboard.stripe.com/products)
2. Click **+ Add product**
3. Fill in:
   - **Name**: Product name
   - **Description**: Product description
   - **Pricing**: Set unit price (in cents, e.g., 2500 = $25.00)
   - **Images**: Add product images

4. **Important**: Add metadata for wholesale features:
   - Click **Add metadata** under the product
   - Add these fields:
     - `category`: Product category (e.g., "Electronics", "Apparel")
     - `moq`: Minimum order quantity (e.g., "10")
     - `packSize`: Pack size/increment (e.g., "5")
     - `inStock`: Set to "true" or "false"

   Example metadata:
   ```
   category: Electronics
   moq: 10
   packSize: 5
   inStock: true
   ```

5. If metadata is missing, defaults will be used:
   - category: "General"
   - moq: 10
   - packSize: 1
   - inStock: true

### 4. Install Dependencies

```bash
npm install
```

### 5. Run Development Server

```bash
npm run dev
```

Visit `http://localhost:3000`

### 6. Build for Production

```bash
npm run build
npm start
```

## How It Works

### Product Sync
Products are pulled from Stripe in real-time. The `/api/stripe/products` endpoint:
1. Fetches all active products from Stripe
2. Reads wholesale metadata (moq, packSize, category)
3. Falls back to defaults if metadata is missing
4. Returns formatted product data

### Cart Validation
The cart enforces these rules:
- Each item quantity must be >= item.moq
- Each item quantity must be a multiple of item.packSize
- Optional: Minimum order subtotal (currently set to $0)
- Checkout is disabled until all items are valid

Validation logic is in:
- `app/cart/page.tsx` - validateItem() function
- `components/QuantitySelector.tsx` - Real-time quantity validation

### Checkout Flow
1. User clicks "Proceed to Checkout" in cart
2. App creates Stripe Checkout session via `/api/stripe/checkout`
3. User is redirected to Stripe's hosted checkout page
4. After payment:
   - Success: Redirects to `/checkout/success?session_id=xxx`
   - Cancel: Redirects back to `/cart`
5. Success page fetches session details and saves order to Supabase
6. Cart is cleared

### Order Storage
Orders are saved to Supabase with:
- Stripe session ID
- Customer email and name
- Line items with quantities
- Subtotal and total amounts
- Order status and timestamps

## Stripe Product Metadata Reference

### Required Metadata Fields

| Field | Type | Example | Default | Description |
|-------|------|---------|---------|-------------|
| `category` | string | "Electronics" | "General" | Product category for filtering |
| `moq` | number | "10" | 10 | Minimum order quantity |
| `packSize` | number | "5" | 1 | Units per pack (quantity increment) |
| `inStock` | boolean | "true" | true | Stock availability |

### Example Product Setup

**Product**: Premium USB Cables (Bulk)
- **Price**: $2.50 each
- **Metadata**:
  - category: "Electronics"
  - moq: "50"
  - packSize: "10"
  - inStock: "true"

This means customers must order at least 50 units, in multiples of 10 (50, 60, 70, etc.)

## Customization

### Minimum Order Subtotal
Edit `app/cart/page.tsx`:
```typescript
const MIN_ORDER_SUBTOTAL = 0; // Change to enforce minimum (in cents)
```

### Default MOQ/Pack Size
Edit `app/api/stripe/products/route.ts`:
```typescript
moq: parseInt(product.metadata?.moq || '10'),
packSize: parseInt(product.metadata?.packSize || '1'),
```

### Categories
Add/modify categories in `app/page.tsx`:
```typescript
const categories = [
  { name: 'Electronics', slug: 'electronics', icon: '📱' },
  // Add more categories
];
```

## Database Schema

The `orders` table in Supabase:
- `id` (uuid) - Unique order ID
- `stripe_session_id` (text) - Stripe Checkout session ID
- `customer_email` (text) - Customer email
- `customer_name` (text) - Customer name
- `items` (jsonb) - Order line items
- `subtotal` (numeric) - Order subtotal
- `total` (numeric) - Order total
- `status` (text) - Order status
- `created_at` (timestamptz) - Creation timestamp

## Troubleshooting

### Products Not Showing
1. Check Stripe API keys in `.env`
2. Ensure products are marked as "Active" in Stripe
3. Ensure products have a default price set
4. Check browser console for API errors

### Checkout Not Working
1. Verify `STRIPE_SECRET_KEY` in `.env`
2. Check that cart items pass validation
3. Ensure success/cancel URLs are correct

### Orders Not Saving
1. Verify Supabase credentials in `.env`
2. Check Supabase RLS policies allow public inserts
3. Check browser console for API errors

## Support

For issues or questions:
- Check Stripe Dashboard for product/payment issues
- Check Supabase Dashboard for database issues
- Review browser console for client-side errors
- Review server logs for API errors

## License

MIT
