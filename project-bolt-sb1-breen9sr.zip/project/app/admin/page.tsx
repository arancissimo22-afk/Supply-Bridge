'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Trash2, CreditCard as Edit, Plus, RefreshCw } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image_url: string;
  category: string;
  stock: number;
  moq: number;
  shipping_cost?: number;
  tax_type?: string;
  stripe_product_id?: string;
}

export default function AdminPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    image_url: '',
    category: '',
    stock: '',
    moq: '1',
    shipping_cost: '',
    tax_type: 'tax_free'
  });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string>('');
  const [shippingData, setShippingData] = useState({
    name: '',
    email: '',
    address: '',
    city: '',
    postal_code: '',
    country: ''
  });
  const [shippingId, setShippingId] = useState<string | null>(null);
  const [paymentData, setPaymentData] = useState({
    bsb: '',
    account_number: ''
  });
  const [paymentId, setPaymentId] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchProducts();
    fetchShippingCredentials();
    fetchPaymentCredentials();
  }, []);

  const fetchProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to fetch products',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchShippingCredentials = async () => {
    try {
      const { data, error } = await supabase
        .from('shipping_credentials')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setShippingData({
          name: data.name,
          email: data.email,
          address: data.address,
          city: data.city,
          postal_code: data.postal_code,
          country: data.country
        });
        setShippingId(data.id);
      }
    } catch (error) {
      console.error('Failed to fetch shipping credentials:', error);
    }
  };

  const fetchPaymentCredentials = async () => {
    try {
      const { data, error } = await supabase
        .from('payment_credentials')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setPaymentData({
          bsb: data.bsb,
          account_number: data.account_number
        });
        setPaymentId(data.id);
      }
    } catch (error) {
      console.error('Failed to fetch payment credentials:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.price.trim() || !formData.image_url.trim()) {
      toast({
        title: 'Error',
        description: 'Please fill in all required fields',
        variant: 'destructive'
      });
      return;
    }

    try {
      const productData = {
        name: formData.name,
        description: formData.description,
        price: parseFloat(formData.price),
        image_url: formData.image_url,
        category: formData.category || 'General',
        stock: parseInt(formData.stock) || 0,
        moq: parseInt(formData.moq) || 1,
        shipping_cost: formData.shipping_cost ? parseFloat(formData.shipping_cost) : 0,
        tax_type: formData.tax_type
      };

      if (editingId) {
        const { error } = await supabase
          .from('products')
          .update(productData)
          .eq('id', editingId);

        if (error) throw error;

        toast({
          title: 'Success',
          description: 'Product updated successfully'
        });
      } else {
        const { error } = await supabase
          .from('products')
          .insert([productData]);

        if (error) throw error;

        toast({
          title: 'Success',
          description: 'Product added successfully'
        });
      }

      setFormData({
        name: '',
        description: '',
        price: '',
        image_url: '',
        category: '',
        stock: '',
        moq: '1',
        shipping_cost: '',
        tax_type: 'tax_free'
      });
      setEditingId(null);
      fetchProducts();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to save product',
        variant: 'destructive'
      });
    }
  };

  const handleEdit = (product: Product) => {
    setFormData({
      name: product.name,
      description: product.description,
      price: product.price.toString(),
      image_url: product.image_url,
      category: product.category,
      stock: product.stock.toString(),
      moq: product.moq.toString(),
      shipping_cost: product.shipping_cost?.toString() || '',
      tax_type: product.tax_type || 'tax_free'
    });
    setPreviewUrl(product.image_url);
    setEditingId(product.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this product?')) return;

    try {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: 'Success',
        description: 'Product deleted successfully'
      });
      fetchProducts();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete product',
        variant: 'destructive'
      });
    }
  };

  const cancelEdit = () => {
    setFormData({
      name: '',
      description: '',
      price: '',
      image_url: '',
      category: '',
      stock: '',
      moq: '1',
      shipping_cost: '',
      tax_type: 'tax_free'
    });
    setEditingId(null);
    setPreviewUrl('');
  };

  const handleShippingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!shippingData.name.trim() || !shippingData.email.trim() || !shippingData.address.trim()) {
      toast({
        title: 'Error',
        description: 'Please fill in all required fields',
        variant: 'destructive'
      });
      return;
    }

    try {
      const credentialsData = {
        name: shippingData.name,
        email: shippingData.email,
        address: shippingData.address,
        city: shippingData.city,
        postal_code: shippingData.postal_code,
        country: shippingData.country,
        updated_at: new Date().toISOString()
      };

      if (shippingId) {
        const { error } = await supabase
          .from('shipping_credentials')
          .update(credentialsData)
          .eq('id', shippingId);

        if (error) throw error;
      } else {
        const { data, error } = await supabase
          .from('shipping_credentials')
          .insert([credentialsData])
          .select()
          .single();

        if (error) throw error;
        setShippingId(data.id);
      }

      toast({
        title: 'Success',
        description: 'Shipping credentials saved successfully'
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to save shipping credentials',
        variant: 'destructive'
      });
    }
  };

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!paymentData.bsb.trim() || !paymentData.account_number.trim()) {
      toast({
        title: 'Error',
        description: 'Please fill in all payment fields',
        variant: 'destructive'
      });
      return;
    }

    try {
      const credentialsData = {
        bsb: paymentData.bsb,
        account_number: paymentData.account_number,
        updated_at: new Date().toISOString()
      };

      if (paymentId) {
        const { error } = await supabase
          .from('payment_credentials')
          .update(credentialsData)
          .eq('id', paymentId);

        if (error) throw error;
      } else {
        const { data, error } = await supabase
          .from('payment_credentials')
          .insert([credentialsData])
          .select()
          .single();

        if (error) throw error;
        setPaymentId(data.id);
      }

      toast({
        title: 'Success',
        description: 'Payment credentials saved successfully'
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to save payment credentials',
        variant: 'destructive'
      });
    }
  };

  const handleRefreshFromStripe = async () => {
    setRefreshing(true);
    try {
      const response = await fetch('/api/stripe/products');

      if (!response.ok) {
        throw new Error('Failed to fetch products from Stripe');
      }

      const stripeProducts = await response.json();

      if (!stripeProducts || stripeProducts.length === 0) {
        toast({
          title: 'No products found',
          description: 'No active products found in your Stripe account',
          variant: 'destructive'
        });
        setRefreshing(false);
        return;
      }

      let successCount = 0;
      let errorCount = 0;

      for (const product of stripeProducts) {
        try {
          const { data: existing, error: fetchError } = await supabase
            .from('products')
            .select('id')
            .eq('stripe_product_id', product.id)
            .maybeSingle();

          if (fetchError) {
            console.error('Error checking existing product:', product.name, fetchError);
            errorCount++;
            continue;
          }

          const productData = {
            stripe_product_id: product.id,
            name: product.name,
            description: product.description || '',
            price: product.price,
            image_url: product.image || 'https://images.pexels.com/photos/1191710/pexels-photo-1191710.jpeg',
            category: product.category || 'General',
            stock: 0,
            moq: product.moq || 1,
            shipping_cost: 0,
            tax_type: 'tax_free',
            updated_at: new Date().toISOString()
          };

          let error;
          if (existing) {
            const { error: updateError } = await supabase
              .from('products')
              .update(productData)
              .eq('id', existing.id);
            error = updateError;
          } else {
            const { error: insertError } = await supabase
              .from('products')
              .insert([productData]);
            error = insertError;
          }

          if (error) {
            console.error('Error syncing product:', product.name, error);
            errorCount++;
          } else {
            successCount++;
          }
        } catch (err) {
          console.error('Error processing product:', product.name, err);
          errorCount++;
        }
      }

      if (successCount > 0) {
        toast({
          title: 'Success',
          description: `Synced ${successCount} product${successCount > 1 ? 's' : ''} from Stripe${errorCount > 0 ? ` (${errorCount} failed)` : ''}`
        });
        fetchProducts();
      } else {
        toast({
          title: 'Error',
          description: 'Failed to sync products from Stripe',
          variant: 'destructive'
        });
      }
    } catch (error) {
      console.error('Refresh error:', error);
      toast({
        title: 'Error',
        description: 'Failed to refresh products from Stripe',
        variant: 'destructive'
      });
    } finally {
      setRefreshing(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    try {
      const file = e.target.files?.[0];
      if (!file) return;

      const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
      if (!allowedTypes.includes(file.type)) {
        toast({
          title: 'Invalid file type',
          description: 'Please select a JPEG, PNG, GIF, or WebP image',
          variant: 'destructive'
        });
        e.target.value = '';
        return;
      }

      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: 'File too large',
          description: 'Image size must be less than 5MB',
          variant: 'destructive'
        });
        e.target.value = '';
        return;
      }

      setUploading(true);

      const fileExt = file.name.split('.').pop()?.toLowerCase() || 'jpg';
      const sanitizedFileName = `${Math.random().toString(36).substring(2)}-${Date.now()}.${fileExt}`;

      const { error: uploadError, data: uploadData } = await supabase.storage
        .from('product-images')
        .upload(sanitizedFileName, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) {
        console.error('Upload error:', uploadError);
        throw new Error(uploadError.message || 'Upload failed');
      }

      if (!uploadData?.path) {
        throw new Error('Upload succeeded but no path returned');
      }

      const { data: { publicUrl } } = supabase.storage
        .from('product-images')
        .getPublicUrl(uploadData.path);

      if (!publicUrl) {
        throw new Error('Failed to get public URL for uploaded image');
      }

      setFormData(prev => ({ ...prev, image_url: publicUrl }));
      setPreviewUrl(publicUrl);

      toast({
        title: 'Success',
        description: 'Image uploaded successfully'
      });

      e.target.value = '';
    } catch (error) {
      console.error('Upload error:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to upload image. Please try again.';
      toast({
        title: 'Upload failed',
        description: errorMessage,
        variant: 'destructive'
      });

      if (e.target) {
        e.target.value = '';
      }
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">Admin Dashboard</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Default Shipping Credentials</CardTitle>
            <CardDescription>
              Set default shipping information to be displayed at checkout
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleShippingSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="shipping_name">Business Name *</Label>
                  <Input
                    id="shipping_name"
                    value={shippingData.name}
                    onChange={(e) => setShippingData({ ...shippingData, name: e.target.value })}
                    placeholder="John Doe"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="shipping_email">Email *</Label>
                  <Input
                    id="shipping_email"
                    type="email"
                    value={shippingData.email}
                    onChange={(e) => setShippingData({ ...shippingData, email: e.target.value })}
                    placeholder="john@example.com"
                    required
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="shipping_address">Address *</Label>
                <Input
                  id="shipping_address"
                  value={shippingData.address}
                  onChange={(e) => setShippingData({ ...shippingData, address: e.target.value })}
                  placeholder="123 Main St"
                  required
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="shipping_city">Suburb *</Label>
                  <Input
                    id="shipping_city"
                    value={shippingData.city}
                    onChange={(e) => setShippingData({ ...shippingData, city: e.target.value })}
                    placeholder="New York"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="shipping_postal">Postcode *</Label>
                  <Input
                    id="shipping_postal"
                    value={shippingData.postal_code}
                    onChange={(e) => setShippingData({ ...shippingData, postal_code: e.target.value })}
                    placeholder="10001"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="shipping_country">Country *</Label>
                  <Input
                    id="shipping_country"
                    value={shippingData.country}
                    onChange={(e) => setShippingData({ ...shippingData, country: e.target.value })}
                    placeholder="United States"
                    required
                  />
                </div>
              </div>
              <Button type="submit">
                Save Shipping Credentials
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Payment Details</CardTitle>
            <CardDescription>
              Set default payment account information
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handlePaymentSubmit} className="space-y-4">
              <div>
                <Label htmlFor="bsb">BSB *</Label>
                <Input
                  id="bsb"
                  value={paymentData.bsb}
                  onChange={(e) => setPaymentData({ ...paymentData, bsb: e.target.value })}
                  placeholder="000-000"
                  maxLength={7}
                  required
                />
              </div>
              <div>
                <Label htmlFor="account_number">Account Number *</Label>
                <Input
                  id="account_number"
                  value={paymentData.account_number}
                  onChange={(e) => setPaymentData({ ...paymentData, account_number: e.target.value })}
                  placeholder="12345678"
                  required
                />
              </div>
              <Button type="submit">
                Save Payment Details
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      <div className="flex items-center justify-between mb-6">
        <h2 className="text-3xl font-bold">Product Management</h2>
        <Button
          onClick={handleRefreshFromStripe}
          disabled={refreshing}
          variant="outline"
          size="lg"
        >
          <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
          {refreshing ? 'Syncing from Stripe...' : 'Sync from Stripe'}
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
        <Card>
          <CardHeader>
            <CardTitle>{editingId ? 'Edit Product' : 'Add New Product'}</CardTitle>
            <CardDescription>
              {editingId ? 'Update product information' : 'Add a new product to your catalog'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">Product Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter product name"
                  required
                />
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Enter product description"
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="price">Price ($) *</Label>
                <Input
                  id="price"
                  type="number"
                  step="0.01"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  placeholder="0.00"
                  required
                />
              </div>

              <div>
                <Label htmlFor="image_upload">Product Image *</Label>
                <div className="flex gap-2">
                  <Input
                    id="image_upload"
                    type="file"
                    accept="image/jpeg,image/jpg,image/png,image/gif,image/webp"
                    onChange={handleFileUpload}
                    disabled={uploading}
                    className="flex-1"
                  />
                  {uploading && (
                    <span className="text-sm text-muted-foreground self-center whitespace-nowrap">
                      Uploading...
                    </span>
                  )}
                </div>
                {formData.image_url && (
                  <p className="text-xs text-muted-foreground mt-1 truncate">
                    {formData.image_url}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="category">Category</Label>
                <Input
                  id="category"
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  placeholder="e.g., Electronics, Clothing, Food"
                />
              </div>

              <div>
                <Label htmlFor="stock">Stock Quantity</Label>
                <Input
                  id="stock"
                  type="number"
                  value={formData.stock}
                  onChange={(e) => setFormData({ ...formData, stock: e.target.value })}
                  placeholder="Unlimited"
                  min="0"
                />
              </div>

              <div>
                <Label htmlFor="moq">Minimum Order Quantity (MOQ)</Label>
                <Input
                  id="moq"
                  type="number"
                  value={formData.moq}
                  onChange={(e) => setFormData({ ...formData, moq: e.target.value })}
                  placeholder="1"
                  min="1"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="shipping_cost">Shipping Cost ($)</Label>
                  <Input
                    id="shipping_cost"
                    type="number"
                    step="0.01"
                    value={formData.shipping_cost}
                    onChange={(e) => setFormData({ ...formData, shipping_cost: e.target.value })}
                    placeholder="0.00"
                    min="0"
                  />
                  <p className="text-xs text-muted-foreground mt-1">Leave blank for free shipping</p>
                </div>
                <div>
                  <Label htmlFor="tax_type">Tax Type</Label>
                  <Select
                    value={formData.tax_type}
                    onValueChange={(value) => setFormData({ ...formData, tax_type: value })}
                  >
                    <SelectTrigger id="tax_type">
                      <SelectValue placeholder="Select tax type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="tax_free">Tax Free</SelectItem>
                      <SelectItem value="tax_inclusive">Tax Inclusive</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground mt-1">Choose tax handling for this product</p>
                </div>
              </div>

              <div className="flex gap-2">
                <Button type="submit" className="flex-1">
                  {editingId ? (
                    <>
                      <Edit className="w-4 h-4 mr-2" />
                      Update Product
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Product
                    </>
                  )}
                </Button>
                {editingId && (
                  <Button type="button" variant="outline" onClick={cancelEdit}>
                    Cancel
                  </Button>
                )}
              </div>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Image Preview</CardTitle>
            <CardDescription>Upload an image or enter a URL</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {(formData.image_url || previewUrl) ? (
              <div className="relative">
                <img
                  src={previewUrl || formData.image_url}
                  alt="Preview"
                  className="w-full h-64 object-cover rounded-lg"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = 'https://images.pexels.com/photos/1191710/pexels-photo-1191710.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop';
                    toast({
                      title: 'Invalid image',
                      description: 'The image URL is invalid or could not be loaded',
                      variant: 'destructive'
                    });
                  }}
                />
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  className="absolute top-2 right-2"
                  onClick={() => {
                    setFormData(prev => ({ ...prev, image_url: '' }));
                    setPreviewUrl('');
                  }}
                >
                  Change Image
                </Button>
              </div>
            ) : (
              <label
                htmlFor="preview_file_upload"
                className={`w-full h-64 bg-muted rounded-lg flex flex-col items-center justify-center text-muted-foreground transition-colors border-2 border-dashed border-muted-foreground/20 ${
                  uploading ? 'cursor-not-allowed opacity-50' : 'cursor-pointer hover:bg-muted/70'
                }`}
              >
                <svg className="w-12 h-12 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                </svg>
                <p className="text-sm font-medium">
                  {uploading ? 'Uploading...' : 'Click to upload an image'}
                </p>
                <p className="text-xs mt-1">PNG, JPEG, GIF, or WebP (max 5MB)</p>
                <input
                  id="preview_file_upload"
                  type="file"
                  accept="image/jpeg,image/jpg,image/png,image/gif,image/webp"
                  onChange={handleFileUpload}
                  disabled={uploading}
                  className="hidden"
                />
              </label>
            )}

            <div className="space-y-2">
              <Label htmlFor="preview_url" className="text-sm">Or enter an image URL:</Label>
              <Input
                id="preview_url"
                value={formData.image_url}
                onChange={(e) => {
                  setFormData({ ...formData, image_url: e.target.value });
                  setPreviewUrl(e.target.value);
                }}
                placeholder="https://example.com/image.jpg"
                disabled={uploading}
              />
            </div>

            {uploading && (
              <div className="text-center text-sm text-muted-foreground">
                Uploading image...
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Product List ({products.length})</CardTitle>
          <CardDescription>Manage your existing products</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p>Loading products...</p>
          ) : products.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              No products yet. Add your first product above!
            </p>
          ) : (
            <div className="space-y-4">
              {products.map((product) => (
                <div
                  key={product.id}
                  className="flex items-center gap-4 p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <img
                    src={product.image_url}
                    alt={product.name}
                    className="w-20 h-20 object-cover rounded"
                  />
                  <div className="flex-1">
                    <h3 className="font-semibold">{product.name}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-1">
                      {product.description}
                    </p>
                    <div className="flex gap-4 mt-1 text-sm">
                      <span className="font-medium">${product.price}</span>
                      <span className="text-muted-foreground">Stock: {product.stock > 0 ? product.stock : 'Unlimited'}</span>
                      <span className="text-muted-foreground">MOQ: {product.moq}</span>
                      <span className="text-muted-foreground">{product.category}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEdit(product)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(product.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
