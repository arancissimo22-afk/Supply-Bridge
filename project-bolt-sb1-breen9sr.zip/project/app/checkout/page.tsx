"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useCart } from '@/contexts/CartContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { CreditCard, Loader as Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';

export default function CheckoutPage() {
  const router = useRouter();
  const { items, getSubtotal, clearCart } = useCart();
  const [loading, setLoading] = useState(false);
  const [loadingCredentials, setLoadingCredentials] = useState(true);
  const [formData, setFormData] = useState({
    email: '',
    name: '',
    address: '',
    city: '',
    postalCode: '',
    country: ''
  });

  useEffect(() => {
    if (items.length === 0) {
      router.push('/cart');
    } else {
      fetchShippingCredentials();
    }
  }, [items, router]);

  const fetchShippingCredentials = async () => {
    try {
      const { data, error } = await supabase
        .from('shipping_credentials')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setFormData(prev => ({
          ...prev,
          name: data.name,
          email: data.email,
          address: data.address,
          city: data.city,
          postalCode: data.postal_code,
          country: data.country
        }));
      }
    } catch (error) {
      console.error('Failed to fetch shipping credentials:', error);
    } finally {
      setLoadingCredentials(false);
    }
  };


  const handleSubmit = async () => {
    setLoading(true);

    try {
      const response = await fetch('/api/stripe/checkout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ items }),
      });

      const data = await response.json();

      if (!response.ok) {
        if (response.status === 503) {
          alert('Payment processing is currently unavailable. The store administrator needs to configure Stripe payments.\n\nPlease contact support for alternative payment methods.');
          setLoading(false);
          return;
        }
        throw new Error(data.error || 'Failed to create checkout session');
      }

      if (!data.url) {
        throw new Error('No checkout URL received');
      }

      clearCart();
      window.location.href = data.url;
    } catch (error) {
      console.error('Checkout error:', error);
      setLoading(false);
      const errorMessage = error instanceof Error ? error.message : 'Failed to initiate checkout. Please try again.';
      alert(errorMessage);
    }
  };

  const subtotal = getSubtotal();

  const shipping = items.reduce((total, item) => {
    const itemShipping = (item as any).shipping_cost || 0;
    return total + (Number(itemShipping) * item.quantity);
  }, 0);

  const calculateTax = () => {
    return items.reduce((total, item) => {
      const itemPrice = item.price * item.quantity;
      const taxType = (item as any).tax_type || 'tax_free';

      if (taxType === 'tax_inclusive') {
        return total + (itemPrice * 0.1);
      }
      return total;
    }, 0);
  };

  const tax = calculateTax();
  const total = subtotal + shipping + tax;

  if (items.length === 0) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4 max-w-6xl">
        <h1 className="text-3xl font-bold mb-8">Checkout</h1>

        <div className="grid lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Contact Information</CardTitle>
              </CardHeader>
              <CardContent>
                {loadingCredentials ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin text-gray-400" />
                  </div>
                ) : (
                  <div className="p-3 bg-gray-50 rounded-md">
                    <p className="text-sm text-gray-600 mb-1">Email:</p>
                    <p className="text-gray-900">{formData.email || 'Not set'}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Shipping Address</CardTitle>
                <CardDescription className="text-sm text-gray-600">
                  To update shipping details, please visit the admin section
                </CardDescription>
              </CardHeader>
              <CardContent>
                {loadingCredentials ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin text-gray-400" />
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="p-3 bg-gray-50 rounded-md">
                      <p className="text-sm text-gray-600 mb-1">Business Name:</p>
                      <p className="font-medium text-gray-900">{formData.name || 'Not set'}</p>
                    </div>
                    <div className="p-3 bg-gray-50 rounded-md">
                      <p className="text-sm text-gray-600 mb-1">Address:</p>
                      <p className="text-gray-900">{formData.address || 'Not set'}</p>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 bg-gray-50 rounded-md">
                        <p className="text-sm text-gray-600 mb-1">Suburb:</p>
                        <p className="text-gray-900">{formData.city || 'Not set'}</p>
                      </div>
                      <div className="p-3 bg-gray-50 rounded-md">
                        <p className="text-sm text-gray-600 mb-1">Postcode:</p>
                        <p className="text-gray-900">{formData.postalCode || 'Not set'}</p>
                      </div>
                    </div>
                    <div className="p-3 bg-gray-50 rounded-md">
                      <p className="text-sm text-gray-600 mb-1">Country:</p>
                      <p className="text-gray-900">{formData.country || 'Not set'}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  Payment
                </CardTitle>
                <CardDescription>Complete your purchase securely with Stripe</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 rounded-md border border-blue-200">
                    <p className="text-sm text-blue-900 font-medium mb-1">Secure Checkout</p>
                    <p className="text-xs text-blue-700">
                      You will be redirected to Stripe's secure payment page to complete your purchase
                    </p>
                  </div>
                  <Button onClick={handleSubmit} className="w-full" size="lg" disabled={loading}>
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Redirecting to Stripe...
                      </>
                    ) : (
                      <>
                        <CreditCard className="mr-2 h-4 w-4" />
                        Continue to Payment - ${total.toFixed(2)}
                      </>
                    )}
                  </Button>
                  <div className="flex items-center justify-center gap-2 text-xs text-gray-500">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                    </svg>
                    <span>Secured by Stripe</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card className="sticky top-4">
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {items.map((item) => (
                    <div key={item.id} className="flex gap-3">
                      <div className="relative w-16 h-16 bg-gray-100 rounded overflow-hidden flex-shrink-0">
                        {item.images && item.images.length > 0 && (
                          <img
                            src={item.images[0]}
                            alt={item.name}
                            className="w-full h-full object-cover"
                          />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium text-sm truncate">{item.name}</h3>
                        <p className="text-sm text-gray-600">Qty: {item.quantity}</p>
                      </div>
                      <div className="text-sm font-medium">
                        ${(item.price * item.quantity).toFixed(2)}
                      </div>
                    </div>
                  ))}
                </div>

                <Separator />

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Subtotal</span>
                    <span>${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Shipping</span>
                    <span>${shipping.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Tax</span>
                    <span>${tax.toFixed(2)}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between text-lg font-bold">
                    <span>Total</span>
                    <span>${total.toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
