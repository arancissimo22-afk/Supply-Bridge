'use client';

import { useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useCart } from '@/contexts/CartContext';
import { CheckCircle2, Package } from 'lucide-react';
import Stripe from 'stripe';

export default function SuccessPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { items, clearCart, getSubtotal } = useCart();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [session, setSession] = useState<Stripe.Checkout.Session | null>(null);

  useEffect(() => {
    const sessionId = searchParams.get('session_id');

    if (!sessionId) {
      setError('No session ID provided');
      setLoading(false);
      return;
    }

    if (items.length === 0) {
      setLoading(false);
      return;
    }

    processOrder(sessionId);
  }, [searchParams]);

  const processOrder = async (sessionId: string) => {
    try {
      const sessionRes = await fetch(
        `https://api.stripe.com/v1/checkout/sessions/${sessionId}`,
        {
          headers: {
            Authorization: `Bearer ${process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY}`,
          },
        }
      );

      if (!sessionRes.ok) {
        throw new Error('Failed to fetch session');
      }

      const sessionData = await sessionRes.json();
      setSession(sessionData);

      const orderData = {
        stripe_session_id: sessionId,
        customer_email: sessionData.customer_details?.email || 'unknown@email.com',
        customer_name: sessionData.customer_details?.name || 'Unknown',
        items: items,
        subtotal: getSubtotal(),
        total: sessionData.amount_total || getSubtotal(),
      };

      const orderRes = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderData),
      });

      if (!orderRes.ok) {
        console.error('Failed to save order');
      }

      clearCart();
    } catch (err) {
      console.error('Error processing order:', err);
      setError('Failed to process order');
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(price / 100);
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-16">
        <Card className="max-w-2xl mx-auto">
          <CardContent className="p-12 text-center">
            <p className="text-muted-foreground">Processing your order...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-16">
        <Card className="max-w-2xl mx-auto">
          <CardContent className="p-12 text-center space-y-4">
            <p className="text-destructive">{error}</p>
            <Button asChild>
              <Link href="/shop">Return to Shop</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-16">
      <Card className="max-w-2xl mx-auto">
        <CardContent className="p-12 space-y-8">
          <div className="text-center space-y-4">
            <div className="mx-auto w-16 h-16 rounded-full bg-green-100 flex items-center justify-center">
              <CheckCircle2 className="h-10 w-10 text-green-600" />
            </div>
            <h1 className="text-3xl font-bold">Order Confirmed!</h1>
            <p className="text-muted-foreground">
              Thank you for your wholesale order. We've received your payment and will process your order shortly.
            </p>
          </div>

          {session && session.customer_details && (
            <div className="border-t border-b py-6 space-y-2">
              <h2 className="font-semibold text-lg mb-4">Order Details</h2>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <span className="text-muted-foreground">Order ID:</span>
                <span className="font-mono text-xs">{session.id}</span>

                <span className="text-muted-foreground">Email:</span>
                <span>{session.customer_details.email}</span>

                {session.customer_details.name && (
                  <>
                    <span className="text-muted-foreground">Name:</span>
                    <span>{session.customer_details.name}</span>
                  </>
                )}

                {session.amount_total && (
                  <>
                    <span className="text-muted-foreground">Total:</span>
                    <span className="font-semibold">
                      {formatPrice(session.amount_total)}
                    </span>
                  </>
                )}
              </div>
            </div>
          )}

          {items.length > 0 && (
            <div className="space-y-4">
              <h2 className="font-semibold text-lg">Order Items</h2>
              <div className="space-y-2">
                {items.map((item) => (
                  <div key={item.id} className="flex justify-between text-sm">
                    <span>
                      {item.name} x {item.quantity}
                    </span>
                    <span className="font-semibold">
                      {formatPrice(item.price * item.quantity)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex gap-3">
            <Package className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-semibold text-blue-900 mb-1">What's Next?</p>
              <p className="text-blue-700">
                You'll receive a confirmation email shortly with your order details and tracking information once your order ships.
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <Button asChild className="flex-1">
              <Link href="/shop">Continue Shopping</Link>
            </Button>
            <Button asChild variant="outline" className="flex-1">
              <Link href="/">Back to Home</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
