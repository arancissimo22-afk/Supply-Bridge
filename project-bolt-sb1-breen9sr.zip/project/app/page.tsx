import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import ProductCard from '@/components/ProductCard';
import ImageUploadBox from '@/components/ImageUploadBox';
import { ArrowRight, Truck, Package, Shield, Clock } from 'lucide-react';
import { Product } from '@/types/product';
import { supabase } from '@/lib/supabase';

async function getFeaturedProducts(): Promise<Product[]> {
  try {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(6);

    if (error) {
      console.error('Failed to fetch products:', error);
      return [];
    }

    const formattedProducts: Product[] = (data || []).map((item: any) => ({
      id: item.id,
      name: item.name,
      description: item.description,
      price: Number(item.price),
      images: [item.image_url],
      category: item.category,
      moq: item.moq || 1,
      packSize: 1,
      inStock: true,
      shipping_cost: item.shipping_cost ? Number(item.shipping_cost) : 0,
      tax_type: item.tax_type || 'tax_free'
    }));

    return formattedProducts;
  } catch (error) {
    console.error('Failed to fetch products:', error);
    return [];
  }
}

export default async function Home() {
  const featuredProducts = await getFeaturedProducts();

  return (
    <div className="flex flex-col">
      <section className="bg-gradient-to-b from-gray-50 to-white py-20 md:py-32">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight">
              Wholesale Food Delivery Made Easy
            </h1>
            <p className="text-xl text-muted-foreground">
              Quality Wholesale Foods at Competitive Prices! No account needed – browse, order, and get shipping quotes instantly.
            </p>
          </div>
        </div>
      </section>

      <section className="py-8 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Specialty Products</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <ImageUploadBox />
            <ImageUploadBox />
            <ImageUploadBox />
          </div>

          <div className="max-w-2xl mx-auto">
            <Link
              href="/admin"
              className="group block"
            >
              <Card className="transition-all hover:shadow-xl border-2 hover:border-primary">
                <CardContent className="p-8 flex items-center gap-6">
                  <div className="flex-grow text-left">
                    <h3 className="text-2xl font-bold mb-2 group-hover:text-primary transition-colors">
                      Wholesale Foods List
                    </h3>
                    <p className="text-muted-foreground">
                      Manage and add products to your wholesale catalog
                    </p>
                  </div>
                  <ArrowRight className="h-6 w-6 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all flex-shrink-0" />
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>
      </section>

      {featuredProducts.length > 0 && (
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Featured Products</h2>
              <p className="text-muted-foreground">Popular wholesale items</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>

            <div className="text-center mt-12">
              <Button asChild variant="outline" size="lg">
                <Link href="/shop">View All Products</Link>
              </Button>
            </div>
          </div>
        </section>
      )}

      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why Choose Supplybridge</h2>
            <p className="text-muted-foreground">Simple, fast, and reliable</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center space-y-3">
              <div className="mx-auto w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Truck className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">Fast Shipping</h3>
              <p className="text-sm text-muted-foreground">
                Quick delivery on all wholesale orders
              </p>
            </div>

            <div className="text-center space-y-3">
              <div className="mx-auto w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Package className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">Flexible MOQ</h3>
              <p className="text-sm text-muted-foreground">
                Minimum order quantities that work for your business
              </p>
            </div>

            <div className="text-center space-y-3">
              <div className="mx-auto w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Shield className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">Secure Checkout</h3>
              <p className="text-sm text-muted-foreground">
                Safe and secure payment processing
              </p>
            </div>

            <div className="text-center space-y-3">
              <div className="mx-auto w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Clock className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">No Account Needed</h3>
              <p className="text-sm text-muted-foreground">
                Quick checkout without registration
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-8 text-center">Shipping & Order Information</h2>

            <div className="grid md:grid-cols-2 gap-8">
              <Card className="bg-primary-foreground text-foreground">
                <CardContent className="p-6 space-y-2">
                  <h3 className="font-semibold text-lg">Minimum Order Quantities (MOQ)</h3>
                  <p className="text-sm text-muted-foreground">
                    Each product has its own MOQ to ensure efficient wholesale pricing. MOQs are clearly displayed on product pages.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-primary-foreground text-foreground">
                <CardContent className="p-6 space-y-2">
                  <h3 className="font-semibold text-lg">Pack Sizes</h3>
                  <p className="text-sm text-muted-foreground">
                    Products are sold in specific pack sizes. Your order quantity must be a multiple of the pack size.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-primary-foreground text-foreground">
                <CardContent className="p-6 space-y-2">
                  <h3 className="font-semibold text-lg">Shipping</h3>
                  <p className="text-sm text-muted-foreground">
                    Orders ship within 2-3 business days. Shipping costs calculated at checkout based on your location and order size.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-primary-foreground text-foreground">
                <CardContent className="p-6 space-y-2">
                  <h3 className="font-semibold text-lg">Secure Payments</h3>
                  <p className="text-sm text-muted-foreground">
                    All payments processed securely through Stripe. We accept all major credit cards.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
