'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import QuantitySelector from '@/components/QuantitySelector';
import { useCart } from '@/contexts/CartContext';
import { Product } from '@/types/product';
import { ShoppingCart, Package, Truck, Shield } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';

export default function ProductPage() {
  const params = useParams();
  const router = useRouter();
  const { addItem } = useCart();
  const { toast } = useToast();
  const [product, setProduct] = useState<Product | null>(null);
  const [quantity, setQuantity] = useState(0);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);

  useEffect(() => {
    fetchProduct();
  }, [params.id]);

  useEffect(() => {
    if (product) {
      setQuantity(product.moq);
    }
  }, [product]);

  const fetchProduct = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('id', params.id)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        const formattedProduct: Product = {
          id: data.id,
          name: data.name,
          description: data.description,
          price: Number(data.price),
          images: [data.image_url],
          category: data.category,
          moq: data.moq || 1,
          packSize: 1,
          inStock: true,
          shipping_cost: data.shipping_cost ? Number(data.shipping_cost) : 0,
          tax_type: data.tax_type || 'tax_free'
        };
        setProduct(formattedProduct);
      }
    } catch (error) {
      console.error('Failed to fetch product:', error);
    } finally {
      setLoading(false);
    }
  };

  const isQuantityValid = () => {
    if (!product) return false;
    return quantity >= product.moq && quantity % product.packSize === 0;
  };

  const handleAddToCart = () => {
    if (!product || !isQuantityValid()) return;

    addItem(product, quantity);
    toast({
      title: 'Added to cart',
      description: `${quantity} units of ${product.name} added to your cart.`,
    });
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(price);
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <p className="text-center text-muted-foreground">Loading product...</p>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center space-y-4">
          <p className="text-muted-foreground">Product not found</p>
          <Button onClick={() => router.push('/shop')}>Back to Shop</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid md:grid-cols-2 gap-8 mb-12">
        <div className="space-y-4">
          <div className="relative aspect-square bg-gray-100 rounded-lg overflow-hidden">
            {product.images && product.images.length > 0 ? (
              <Image
                src={product.images[selectedImage]}
                alt={product.name}
                fill
                className="object-cover"
                sizes="(max-width: 768px) 100vw, 50vw"
              />
            ) : (
              <div className="flex h-full items-center justify-center text-muted-foreground">
                No Image
              </div>
            )}
          </div>

          {product.images && product.images.length > 1 && (
            <div className="grid grid-cols-4 gap-2">
              {product.images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(index)}
                  className={`relative aspect-square bg-gray-100 rounded-lg overflow-hidden border-2 ${
                    selectedImage === index ? 'border-primary' : 'border-transparent'
                  }`}
                >
                  <Image
                    src={image}
                    alt={`${product.name} ${index + 1}`}
                    fill
                    className="object-cover"
                    sizes="25vw"
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div>
            <Badge variant="outline" className="mb-2">
              {product.category}
            </Badge>
            <h1 className="text-4xl font-bold mb-2">{product.name}</h1>
            {!product.inStock && (
              <Badge variant="destructive" className="mb-2">
                Out of Stock
              </Badge>
            )}
          </div>

          <div className="flex items-baseline gap-2">
            <span className="text-4xl font-bold">{formatPrice(product.price)}</span>
            <span className="text-xl text-muted-foreground">/ unit</span>
          </div>

          {product.description && (
            <div>
              <h3 className="font-semibold mb-2">Description</h3>
              <p className="text-muted-foreground">{product.description}</p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <Card>
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground mb-1">Minimum Order</p>
                <p className="text-2xl font-bold">{product.moq}</p>
                <p className="text-xs text-muted-foreground">units</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground mb-1">Pack Size</p>
                <p className="text-2xl font-bold">{product.packSize}</p>
                <p className="text-xs text-muted-foreground">units/pack</p>
              </CardContent>
            </Card>
          </div>

          <div className="border-t pt-6">
            <h3 className="font-semibold mb-4">Select Quantity</h3>
            <QuantitySelector
              moq={product.moq}
              packSize={product.packSize}
              value={quantity}
              onChange={setQuantity}
            />
          </div>

          <div className="space-y-3">
            <Button
              size="lg"
              className="w-full"
              onClick={handleAddToCart}
              disabled={!product.inStock || !isQuantityValid()}
            >
              <ShoppingCart className="mr-2 h-5 w-5" />
              Add to Cart
            </Button>

            <p className="text-sm text-center text-muted-foreground">
              Total: {formatPrice(product.price * quantity)}
            </p>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6 flex items-start gap-4">
            <div className="rounded-full bg-primary/10 p-3">
              <Truck className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold mb-1">Fast Shipping</h3>
              <p className="text-sm text-muted-foreground">
                Orders ship within 2-3 business days
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 flex items-start gap-4">
            <div className="rounded-full bg-primary/10 p-3">
              <Package className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold mb-1">Wholesale Pricing</h3>
              <p className="text-sm text-muted-foreground">
                Competitive prices for bulk orders
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 flex items-start gap-4">
            <div className="rounded-full bg-primary/10 p-3">
              <Shield className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold mb-1">Secure Payment</h3>
              <p className="text-sm text-muted-foreground">
                Safe and secure checkout process
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
