import { Suspense } from 'react';
import ShopProducts from '@/components/ShopProducts';
import { Product } from '@/types/product';
import { supabase } from '@/lib/supabase';

async function getProducts(): Promise<Product[]> {
  try {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;

    const formattedProducts: Product[] = (data || []).map((item: any) => ({
      id: item.id,
      name: item.name,
      description: item.description,
      price: Number(item.price),
      images: [item.image_url],
      category: item.category,
      moq: item.moq || 1,
      packSize: 1,
      inStock: true,
      shipping_cost: item.shipping_cost ? Number(item.shipping_cost) : 0,
      tax_type: item.tax_type || 'tax_free'
    }));

    return formattedProducts;
  } catch (error) {
    console.error('Failed to fetch products:', error);
    return [];
  }
}

export const revalidate = 60;

export default async function ShopPage() {
  const products = await getProducts();

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Shop Wholesale Products</h1>
        <p className="text-muted-foreground">Browse our complete catalog</p>
      </div>

      <Suspense fallback={
        <div className="text-center py-12">
          <p className="text-muted-foreground">Loading products...</p>
        </div>
      }>
        <ShopProducts products={products} />
      </Suspense>
    </div>
  );
}
