import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';

const isStripeConfigured = process.env.STRIPE_SECRET_KEY &&
  process.env.STRIPE_SECRET_KEY !== 'your_stripe_secret_key_here' &&
  process.env.STRIPE_SECRET_KEY.startsWith('sk_');

const stripe = isStripeConfigured
  ? new Stripe(process.env.STRIPE_SECRET_KEY!, {
      apiVersion: '2026-02-25.clover',
    })
  : null;

export async function POST(request: NextRequest) {
  try {
    const { items } = await request.json();

    console.log('Received checkout request with items:', JSON.stringify(items, null, 2));

    if (!items || items.length === 0) {
      return NextResponse.json(
        { error: 'No items in cart' },
        { status: 400 }
      );
    }

    if (!isStripeConfigured || !stripe) {
      return NextResponse.json(
        { error: 'Payment processing is not configured. Please contact the administrator to set up Stripe payments.' },
        { status: 503 }
      );
    }

    const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';
    const isLiveMode = process.env.STRIPE_SECRET_KEY?.startsWith('sk_live_');
    const isLocalhost = appUrl.includes('localhost') || appUrl.includes('127.0.0.1');

    if (isLiveMode && isLocalhost) {
      return NextResponse.json(
        { error: 'Stripe live mode cannot redirect to localhost. Please either use Stripe test keys (sk_test_...) for local development, or deploy to a production URL and update NEXT_PUBLIC_APP_URL in your .env file.' },
        { status: 400 }
      );
    }

    const lineItems: Stripe.Checkout.SessionCreateParams.LineItem[] = [];

    items.forEach((item: any) => {
      const itemPrice = item.price * 100;
      const shippingCost = (item.shipping_cost || 0) * 100;
      const taxType = item.tax_type || 'tax_free';

      let itemPriceWithTax = itemPrice;
      if (taxType === 'tax_inclusive') {
        itemPriceWithTax = itemPrice + (itemPrice * 0.1);
      }

      const productData: Stripe.Checkout.SessionCreateParams.LineItem.PriceData.ProductData = {
        name: item.name,
        images: item.images?.length > 0 ? [item.images[0]] : [],
      };

      if (item.description && item.description.trim()) {
        productData.description = item.description.trim();
      }

      lineItems.push({
        price_data: {
          currency: 'usd',
          product_data: productData,
          unit_amount: Math.round(itemPriceWithTax),
        },
        quantity: item.quantity,
      });

      if (shippingCost > 0) {
        lineItems.push({
          price_data: {
            currency: 'usd',
            product_data: {
              name: `Shipping for ${item.name}`,
            },
            unit_amount: Math.round(shippingCost),
          },
          quantity: item.quantity,
        });
      }
    });

    const successUrl = `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/checkout/success?session_id={CHECKOUT_SESSION_ID}`;
    const cancelUrl = `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/cart`;

    console.log('Creating Stripe session with:', {
      successUrl,
      cancelUrl,
      lineItemsCount: lineItems.length
    });

    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items: lineItems,
      success_url: successUrl,
      cancel_url: cancelUrl,
      phone_number_collection: {
        enabled: true,
      },
    });

    console.log('Stripe session created:', session.id, 'URL:', session.url);

    return NextResponse.json({ url: session.url });
  } catch (error: any) {
    console.error('Checkout error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to create checkout session' },
      { status: 500 }
    );
  }
}
