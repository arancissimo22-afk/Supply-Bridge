import { NextResponse } from 'next/server';
import Stripe from 'stripe';

const isStripeConfigured = process.env.STRIPE_SECRET_KEY &&
  process.env.STRIPE_SECRET_KEY !== 'your_stripe_secret_key_here' &&
  process.env.STRIPE_SECRET_KEY.startsWith('sk_');

const stripe = isStripeConfigured
  ? new Stripe(process.env.STRIPE_SECRET_KEY!, {
      apiVersion: '2026-02-25.clover',
    })
  : null;

export async function GET() {
  try {
    if (!isStripeConfigured || !stripe) {
      console.log('Stripe not configured, returning empty products array');
      return NextResponse.json([], { status: 200 });
    }

    const products = await stripe.products.list({
      active: true,
      expand: ['data.default_price'],
    });

    const formattedProducts = products.data.map((product) => {
      const price = product.default_price as Stripe.Price;

      return {
        id: product.id,
        name: product.name,
        description: product.description || '',
        price: price ? (price.unit_amount || 0) / 100 : 0,
        image: product.images[0] || 'https://via.placeholder.com/400',
        category: product.metadata?.category || 'Uncategorized',
        moq: parseInt(product.metadata?.moq || '1'),
        packSize: parseInt(product.metadata?.packSize || '1'),
        priceId: price?.id || '',
      };
    });

    return NextResponse.json(formattedProducts);
  } catch (error: any) {
    console.error('Error fetching Stripe products:', error?.message || error);
    return NextResponse.json([], { status: 200 });
  }
}
