'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useCart } from '@/contexts/CartContext';
import { Trash2, ShoppingBag, ArrowLeft } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const MIN_ORDER_SUBTOTAL = 0;

export default function CartPage() {
  const router = useRouter();
  const { items, updateQuantity, removeItem, getSubtotal } = useCart();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(price);
  };

  const validateItem = (item: any) => {
    const errors = [];

    if (item.quantity < item.moq) {
      errors.push(`Quantity must be at least ${item.moq} (MOQ)`);
    }

    return errors;
  };

  const isCartValid = () => {
    if (items.length === 0) return false;

    const subtotal = getSubtotal();
    if (subtotal < MIN_ORDER_SUBTOTAL) return false;

    return items.every((item) => validateItem(item).length === 0);
  };

  const handleQuantityChange = (productId: string, newQuantity: number) => {
    if (newQuantity > 0) {
      updateQuantity(productId, newQuantity);
    }
  };

  const handleCheckout = () => {
    if (!isCartValid()) {
      toast({
        title: 'Cart validation failed',
        description: 'Please fix all errors before proceeding to checkout.',
        variant: 'destructive',
      });
      return;
    }

    router.push('/checkout');
  };

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16">
        <Card className="max-w-md mx-auto">
          <CardContent className="p-12 text-center space-y-4">
            <ShoppingBag className="h-16 w-16 mx-auto text-muted-foreground" />
            <h2 className="text-2xl font-bold">Your cart is empty</h2>
            <p className="text-muted-foreground">
              Add some products to your cart to get started
            </p>
            <Button asChild className="w-full">
              <Link href="/shop">Browse Products</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const subtotal = getSubtotal();

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Button variant="ghost" asChild className="mb-4">
          <Link href="/shop">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Continue Shopping
          </Link>
        </Button>
        <h1 className="text-4xl font-bold">Shopping Cart</h1>
        <p className="text-muted-foreground">
          {items.length} item{items.length !== 1 ? 's' : ''} in your cart
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
          {items.map((item) => {
            const errors = validateItem(item);
            const itemTotal = item.price * item.quantity;

            return (
              <Card key={item.id}>
                <CardContent className="p-6">
                  <div className="flex gap-4">
                    <div className="relative w-24 h-24 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                      {item.images && item.images.length > 0 ? (
                        <Image
                          src={item.images[0]}
                          alt={item.name}
                          fill
                          className="object-cover"
                          sizes="96px"
                        />
                      ) : (
                        <div className="flex h-full items-center justify-center text-xs text-muted-foreground">
                          No Image
                        </div>
                      )}
                    </div>

                    <div className="flex-1 space-y-2">
                      <div className="flex justify-between gap-4">
                        <div>
                          <h3 className="font-semibold">{item.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {formatPrice(item.price)} per unit
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeItem(item.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                          <label className="text-sm font-medium">Quantity:</label>
                          <Input
                            type="number"
                            value={item.quantity}
                            onChange={(e) =>
                              handleQuantityChange(item.id, parseInt(e.target.value) || 0)
                            }
                            min={item.moq}
                            step={1}
                            className="w-24"
                          />
                        </div>

                        <div className="text-sm text-muted-foreground">
                          MOQ: {item.moq}
                        </div>
                      </div>

                      {errors.length > 0 && (
                        <div className="space-y-1">
                          {errors.map((error, index) => (
                            <p key={index} className="text-sm text-destructive">
                              {error}
                            </p>
                          ))}
                        </div>
                      )}

                      <div className="text-right">
                        <p className="text-lg font-bold">{formatPrice(itemTotal)}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="lg:col-span-1">
          <Card className="sticky top-20">
            <CardContent className="p-6 space-y-4">
              <h2 className="text-xl font-bold">Order Summary</h2>

              <div className="space-y-2 border-t pt-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span className="font-semibold">{formatPrice(subtotal)}</span>
                </div>

                {MIN_ORDER_SUBTOTAL > 0 && subtotal < MIN_ORDER_SUBTOTAL && (
                  <p className="text-sm text-destructive">
                    Minimum order subtotal: {formatPrice(MIN_ORDER_SUBTOTAL)}
                  </p>
                )}

                <div className="text-sm text-muted-foreground">
                  Shipping calculated at checkout
                </div>
              </div>

              <div className="border-t pt-4">
                <Button
                  size="lg"
                  className="w-full"
                  onClick={handleCheckout}
                  disabled={!isCartValid() || loading}
                >
                  {loading ? 'Processing...' : 'Proceed to Checkout'}
                </Button>
              </div>

              {!isCartValid() && items.length > 0 && (
                <p className="text-sm text-destructive text-center">
                  Please fix cart errors before checkout
                </p>
              )}

              <div className="text-xs text-muted-foreground text-center pt-2">
                Secure checkout powered by Stripe
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
