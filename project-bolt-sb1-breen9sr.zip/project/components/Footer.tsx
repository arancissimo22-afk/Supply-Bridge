'use client';

import Link from 'next/link';
import { Package, Mail, Phone, MapPin } from 'lucide-react';

interface FooterContent {
  businessName: string;
  headline: string;
  description: string;
  email: string;
  phone: string;
  address: string;
  website?: string;
  copyrightText: string;
}

interface FooterProps {
  content?: FooterContent;
}

const defaultContent: FooterContent = {
  businessName: 'Supplybridge',
  headline: 'Supplybridge',
  description: 'Your trusted partner for wholesale products. Quality goods at competitive prices.',
  email: 'orders@supplybridge.com',
  phone: '1-800-WHOLESALE',
  address: '123 Business Ave, Commerce City',
  copyrightText: 'Supplybridge. All rights reserved.',
};

export default function Footer({ content = defaultContent }: FooterProps) {
  const footerData = { ...defaultContent, ...content };

  return (
    <footer className="border-t bg-gray-50">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 font-bold text-xl mb-4">
              <Package className="h-6 w-6" />
              <span>{footerData.businessName}</span>
            </div>
            <p className="text-sm text-muted-foreground">
              {footerData.description}
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/" className="text-muted-foreground hover:text-foreground">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/shop" className="text-muted-foreground hover:text-foreground">
                  Shop
                </Link>
              </li>
              <li>
                <Link href="/cart" className="text-muted-foreground hover:text-foreground">
                  Cart
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Policies</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-muted-foreground hover:text-foreground">
                  Shipping Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-foreground">
                  Return Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-foreground">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-foreground">
                  Privacy Policy
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3 text-sm">
              <li className="text-muted-foreground">
                Email: {footerData.email}
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} {footerData.copyrightText}</p>
        </div>
      </div>
    </footer>
  );
}
