'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Minus, Plus } from 'lucide-react';

interface QuantitySelectorProps {
  moq: number;
  packSize: number;
  value: number;
  onChange: (value: number) => void;
  showErrors?: boolean;
}

export default function QuantitySelector({
  moq,
  packSize,
  value,
  onChange,
  showErrors = true,
}: QuantitySelectorProps) {
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    validateQuantity(value);
  }, [value, moq, packSize]);

  const validateQuantity = (qty: number) => {
    if (qty < moq) {
      setError(`Minimum order quantity is ${moq}`);
      return false;
    }
    if (qty % packSize !== 0) {
      setError(`Quantity must be a multiple of pack size (${packSize})`);
      return false;
    }
    setError(null);
    return true;
  };

  const handleIncrement = () => {
    onChange(value + packSize);
  };

  const handleDecrement = () => {
    const newValue = value - packSize;
    if (newValue >= moq) {
      onChange(newValue);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = parseInt(e.target.value) || 0;
    onChange(newValue);
  };

  const snapToNearestValid = () => {
    if (value < moq) {
      onChange(moq);
      return;
    }
    const remainder = value % packSize;
    if (remainder !== 0) {
      const snapped = value - remainder + (remainder >= packSize / 2 ? packSize : 0);
      onChange(Math.max(snapped, moq));
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <Button
          type="button"
          variant="outline"
          size="icon"
          onClick={handleDecrement}
          disabled={value - packSize < moq}
        >
          <Minus className="h-4 w-4" />
        </Button>

        <Input
          type="number"
          value={value}
          onChange={handleInputChange}
          onBlur={snapToNearestValid}
          min={moq}
          step={packSize}
          className="w-24 text-center"
        />

        <Button
          type="button"
          variant="outline"
          size="icon"
          onClick={handleIncrement}
        >
          <Plus className="h-4 w-4" />
        </Button>
      </div>

      {showErrors && error && (
        <p className="text-sm text-destructive">{error}</p>
      )}

      <div className="text-xs text-muted-foreground">
        <p>MOQ: {moq} units</p>
        <p>Pack Size: {packSize} units</p>
      </div>
    </div>
  );
}
